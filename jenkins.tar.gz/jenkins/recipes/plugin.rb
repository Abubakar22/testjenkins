 
#Install version 1.3 of the greenballs plugin
 jenkins_plugin 'git' do
   end
 #Install version 1.3 of the crowd plugin
 jenkins_plugin 'crowd' do
   end
 #Install version 1.3 of the crowd plugin
 jenkins_plugin 'maven' do
   end
